Thank you for support our asset!

*IMPORTANT* This asset requires Unity 2018.4.12f1 LTS or higher.

If you have any question about how it works or if you are experiencing any trouble, 
feel free to email us at: inv3ctor@gmail.com
Please do not Upload or share this asset as a package without permission.

If you downloaded this asset illegally for studies or prototype purposes, 
please reconsider purchase if you want to publish your work, you can buy on the AssetStore or the vStore
or send us a email and we can figure something out, you can even post your work on our Forum, 
we will be happy to help and advertise your game.

It has been more than 4 years since the release of v1.0 and we continue to work on this only because of your support, 
otherwise we will have to find day jobs and we would never had time to work on this, so thank you!

ASSETSTORE: https://www.assetstore.unity3d.com/en/#!/content/44227
VSTORE: https://sellfy.com/invector
FORUM: http://invector.proboards.com/
YOUTUBE: https://www.youtube.com/channel/UCSEoY03WFn7D0m1uMi6DxZQ
WEBSITE: http://www.invector.xyz/
PATREON: https://www.patreon.com/invector
ONLINE DOCUMENTATION: https://www.invector.xyz/thirdpersondocumentation

Invector Team - 2020

Basic Locomotion FREE LITE v2.0 - 17/01/2020

- Recreated the whole project based on the Basic Locomotion v2.5.0
- New 3D Models, Animations, Animator, Core Scripts, Ground Detection, SlopeLimit, Jump Physics, Movement & Rotation 