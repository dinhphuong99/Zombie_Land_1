using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectionCollider : MonoBehaviour
{
    [SerializeField] private string tagDetection;
    [HideInInspector] public List<GameObject> objectDetections = new List<GameObject>();
    public bool isTouch { get; private set; }

    private void Start()
    {
        this.isTouch = false;
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.CompareTag(tagDetection))
        {
            isTouch = true;
            objectDetections.Add(collision.gameObject);
        }
    }

    private void OnTriggerExit(Collider collision)
    {
        if (collision.gameObject.CompareTag(tagDetection))
        {
            isTouch = false;
            foreach(GameObject obj in objectDetections)
            {
                if(obj.GetInstanceID() == collision.gameObject.GetInstanceID())
                {
                    objectDetections.Remove(obj);
                    break;
                }
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag(tagDetection))
        {
            isTouch = true;
            objectDetections.Add(collision.gameObject);
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag(tagDetection))
        {
            isTouch = false;
            foreach (GameObject obj in objectDetections)
            {
                if (obj.GetInstanceID() == collision.gameObject.GetInstanceID())
                {
                    objectDetections.Remove(obj);
                    break;
                }
            }
        }
    }
}