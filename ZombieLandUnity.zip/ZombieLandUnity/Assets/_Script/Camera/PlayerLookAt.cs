﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLookAt : MonoBehaviour
{
    [SerializeField] private GameObject aimPos;
    [SerializeField] private float aimSmoothSpeed = 20f;
    [SerializeField] private LayerMask aimMask;
    [SerializeField] private Camera CameraMain;

    public bool setAimPosPosition = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 screenCentre = new Vector2(Screen.width / 2, Screen.height / 2); 
        Ray ray = CameraMain.ScreenPointToRay(screenCentre);
        if (Physics.Raycast(ray, out RaycastHit hit, Mathf.Infinity, aimMask))
        {
            aimPos.transform.position = Vector3.Lerp(aimPos.transform.position, hit.point, aimSmoothSpeed * Time.deltaTime);
            setAimPosPosition = true;
        }
        else
        {
            aimPos.transform.position = ray.GetPoint(75f);
            setAimPosPosition = false;
        }
    }
}
