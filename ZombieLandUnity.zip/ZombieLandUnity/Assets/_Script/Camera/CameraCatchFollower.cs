using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCatchFollower : MonoBehaviour
{
    public GameObject [] waypoints;
    [SerializeField] private float speed = 200f;
    public LayerMask wallLayer;
    public GameObject lookpoint;

    public int curentIndex = 1;

    private float raycastDistance = 0f;
    RaycastHit hit;
    Vector3 directRay;

    private bool CheckWall()
    {
        raycastDistance = Vector3.Distance(transform.position, lookpoint.transform.position);
        directRay = (transform.position - lookpoint.transform.position).normalized;

        Physics.Raycast(transform.position, directRay, out hit, raycastDistance, wallLayer);

        if(hit.collider != null && hit.collider.gameObject != null)
        {
            return true;
        }
        return false;
    }

    private void SwapCamera()
    {
        if (Input.GetButtonDown("SwapCamera"))
        {
            if (curentIndex == 1 | curentIndex == 0)
                curentIndex = 2;
            else if (curentIndex == 3 | curentIndex == 2)
                curentIndex = 0;
        }
    }
    // Update is called once per frame
    void Update()
    {
        SwapCamera();
        Debug.Log("index " + curentIndex);

        //if (CheckWall())
        //{
        //    if (curentIndex == 1)
        //        curentIndex = 0;
        //    if (curentIndex == 3)
        //        curentIndex = 2;
        //}
        //else if (!CheckWall())
        //{
        //    if (curentIndex == 0)
        //        curentIndex = 1;
        //    if (curentIndex == 2)
        //        curentIndex = 3;
        //}
        if(Vector3.Distance(waypoints[curentIndex].transform.position,
            transform.position) < 0.1f)
        transform.position = Vector3.MoveTowards(transform.position, waypoints[curentIndex].transform.position, Time.deltaTime * speed);
    }
}
