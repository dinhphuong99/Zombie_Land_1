using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectSendDamageCollider : MonoBehaviour
{
    [SerializeField] protected string tagTakeDamage;
    protected Life life;
    public List<GameObjectCanSent> ListObjectSentDamage = new List<GameObjectCanSent>();
    public List<GameObject> ListObjectExit = new List<GameObject>();

    public class GameObjectCanSent
    {
        public GameObject obj;
        public bool isSent;
    }

    // Start is called before the first frame update
    void Start()
    {
        ListObjectSentDamage.Clear();
        ListObjectExit.Clear();

        Collider colliderComponent = GetComponent<Collider>();
        if (colliderComponent == null)
        {
            colliderComponent = gameObject.AddComponent<MeshCollider>();
            colliderComponent.isTrigger = true;
        }

        Rigidbody rigidbodyComponent = GetComponent<Rigidbody>();
        if (rigidbodyComponent == null)
        {
            rigidbodyComponent = gameObject.AddComponent<Rigidbody>();
            rigidbodyComponent.useGravity = false;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {

            if (!(CheckObjectInList(collision.gameObject) > -1)
                && (collision.gameObject.GetComponent<Life>() != null))
            {
                GameObjectCanSent gameObjectCanSent = new GameObjectCanSent();
                gameObjectCanSent.obj = collision.gameObject;
                gameObjectCanSent.isSent = false;

                ListObjectSentDamage.Add(gameObjectCanSent);
            }
        }

    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {
            if (!(CheckObjectInList(collision.gameObject) > -1)
                && (collision.gameObject.GetComponent<Life>() != null))
            {
                GameObjectCanSent gameObjectCanSent = new GameObjectCanSent();
                gameObjectCanSent.obj = collision.gameObject;
                gameObjectCanSent.isSent = false;

                ListObjectSentDamage.Add(gameObjectCanSent);
            }
        }

    }


    protected void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {
            ListObjectExit.Add(collision.gameObject);
        }
    }

    protected void OnTriggerExit(Collider collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {
            ListObjectExit.Add(collision.gameObject);
        }
    }

    private int CheckObjectInList(GameObject obj)
    {
        for (int i = 0; i < ListObjectSentDamage.Count; i++)
        {
            if (ListObjectSentDamage[i].obj.GetInstanceID() == obj.GetInstanceID())
            {
                return i;
            }
        }

        return -1;
    }

    public void RemoveObjectInList()
    {
        foreach (GameObject gameObject in ListObjectExit)
        {
            try
            {
                ListObjectSentDamage.RemoveAt(CheckObjectInList(gameObject));
            }
            catch (Exception e)
            {

            }
        }
        ListObjectExit.Clear();
    }
}
