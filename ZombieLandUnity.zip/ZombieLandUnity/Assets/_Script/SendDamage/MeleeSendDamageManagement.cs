using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeSendDamageManagement : MonoBehaviour
{
    [SerializeField] private GameObject[] objectSendDamage;
    [SerializeField] protected bool isSent = false;
    protected MeleeSendDamage meleeSendDamage;
    protected TestCollider testCollider;

    public void SetFalse2IsSent()
    {
        for (int i = 0; i < objectSendDamage.Length; i++)
        {
            meleeSendDamage = objectSendDamage[i].GetComponent<MeleeSendDamage>();
            testCollider = objectSendDamage[i].GetComponent<TestCollider>();

            if (meleeSendDamage != null)
            {
                meleeSendDamage.SetFalse2IsSent();
                testCollider.SetFalse2IsSent();
            }
        }
    
    }

    public void SetTrue2IsSent()
    {

        for (int i = 0; i < objectSendDamage.Length; i++)
        {
            meleeSendDamage = objectSendDamage[i].GetComponent<MeleeSendDamage>();
            testCollider = objectSendDamage[i].GetComponent<TestCollider>();

            if (meleeSendDamage != null)
            {
                meleeSendDamage.SetTrue2IsSent();
                testCollider.SetTrue2IsSent();
            }
        }

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
