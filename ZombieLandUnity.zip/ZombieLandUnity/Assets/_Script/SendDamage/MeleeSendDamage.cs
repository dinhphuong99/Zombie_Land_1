﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using ObjectSend = ObjectSendDamageCollider.GameObjectCanSent;

public class MeleeSendDamage : MonoBehaviour
{
    public float damage = 10f;
    protected Life life;
    [HideInInspector] public bool isSent = false;
    [HideInInspector] public bool isTouch = false;
    public ObjectSendDamageCollider damageCollider;

    // Start is called before the first frame update
    void Start()
    {
        this.isSent = true;
    }


    public void SetFalse2IsSent()
    {
        this.isSent = false;
    }

    public void SetTrue2IsSent()
    {
        this.isSent = true;
        foreach (ObjectSend gameObject in damageCollider.ListObjectSentDamage)
        {
            gameObject.isSent = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (damageCollider.ListObjectSentDamage.Count() > 0)
        {
            isTouch = true;
        }
        else
        {
            isTouch = false;
        }

        if (!this.isSent)
        {
            foreach (ObjectSend gameObject in damageCollider.ListObjectSentDamage)
            {
                SendDamage(gameObject);
            }
        }
        else
        {
            damageCollider.RemoveObjectInList();
        }
    }

    private void SendDamage(ObjectSend gameObjectCanSent)
    {
        if (!gameObjectCanSent.isSent)
        {
            life = gameObjectCanSent.obj.GetComponent<Life>();

            if (life != null)
            {
                life.TakeDamage(damage);
                gameObjectCanSent.isSent = true;
            }
        }

    }
}