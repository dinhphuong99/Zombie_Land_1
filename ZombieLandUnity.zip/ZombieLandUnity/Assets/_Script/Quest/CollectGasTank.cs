﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectGasTank : MonoBehaviour
{
    public GameObject gasTank;
    public GameObject player;
    public float distanceCollect = 6f;

    private void Start()
    {
        PlayerPrefs.SetInt("collectGT", 0);
        PlayerPrefs.Save();
    }
    // Update is called once per frame
    void Update()
    {
        // Tính toán khoảng cách giữa gasTank và player
        float distance = Vector3.Distance(gasTank.transform.position, player.transform.position);

        // Kiểm tra nếu khoảng cách nhỏ hơn 6f và nút "PickUp" được nhấn
        if (distance < distanceCollect && Input.GetButton("PickUp"))
        {
            PlayerPrefs.SetInt("collectGT", 1);
            PlayerPrefs.Save();

            // Phá hủy đối tượng gasTank sau khi thu thập thành công
            Destroy(gasTank);
        }
    }
}
