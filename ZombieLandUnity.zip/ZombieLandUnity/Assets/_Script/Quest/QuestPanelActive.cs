using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestPanelActive : MonoBehaviour
{
    [SerializeField] private GameObject questPanel;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void QuestView()
    {
        questPanel.SetActive(true);
        Time.timeScale = 0f;
    }

    public void CloseQuestView()
    {
        questPanel.SetActive(false);
        Time.timeScale = 1f;
    }
}
