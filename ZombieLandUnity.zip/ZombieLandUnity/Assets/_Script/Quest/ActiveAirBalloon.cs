﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActiveAirBalloon : MonoBehaviour
{
    public GameObject airBalloon;
    public Rigidbody airBallonRib;
    public float distanceActive = 8f;

    public GameObject player;

    public float distanceCheck;
    public LayerMask enemyMask;
    [SerializeField] private GameObject victoryPanel;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        ActiveAB();
    }

    public bool CheckZombie()
    {
        // Tạo một hình cầu với tâm là vị trí của airBalloon và bán kính là distanceCheck
        Collider[] hitColliders = Physics.OverlapSphere(airBalloon.transform.position, distanceCheck, enemyMask);

        // Kiểm tra nếu có bất kỳ collider nào nằm trong hình cầu này
        if (hitColliders.Length > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void ActiveAB()
    {
        if (!CheckZombie() && PlayerPrefs.GetInt("collectGT") > 0)
        {
            airBallonRib.useGravity = true;
        }

        // Tính toán khoảng cách giữa airBalloon và player
        float distance = Vector3.Distance(airBalloon.transform.position, player.transform.position);

        // Kiểm tra nếu khoảng cách nhỏ hơn 6f và nút "PickUp" được nhấn
        if (distance < distanceActive && Input.GetButton("PickUp"))
        {
            victoryPanel.SetActive(true);
            Time.timeScale = 0f;
        }
    }
}
