﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SoundManager : MonoBehaviour
{
    [SerializeField] private Slider sliderVolume;

    // Start is called before the first frame update
    void Start()
    {
        // Kiểm tra nếu "musicVolume" không tồn tại trong PlayerPrefs, thì đặt giá trị mặc định
        if (!PlayerPrefs.HasKey("musicVolume"))
        {
            PlayerPrefs.SetFloat("musicVolume", 1);
        }

        // Luôn tải giá trị từ PlayerPrefs khi bắt đầu
        Load();
    }

    // Update is called once per frame
    void Update()
    {

    }

    // Phương thức được gọi khi giá trị của thanh trượt thay đổi
    public void ChangeVolume()
    {
        AudioListener.volume = sliderVolume.value;
        Save();
    }

    // Lưu giá trị âm lượng hiện tại vào PlayerPrefs
    private void Save()
    {
        PlayerPrefs.SetFloat("musicVolume", sliderVolume.value);
        PlayerPrefs.Save(); // Đảm bảo lưu ngay lập tức
    }

    // Tải giá trị âm lượng từ PlayerPrefs và cập nhật thanh trượt
    private void Load()
    {
        sliderVolume.value = PlayerPrefs.GetFloat("musicVolume");
        AudioListener.volume = sliderVolume.value; // Đảm bảo âm lượng được cập nhật khi tải
    }
}