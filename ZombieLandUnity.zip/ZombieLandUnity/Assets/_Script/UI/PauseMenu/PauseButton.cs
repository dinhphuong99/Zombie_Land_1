using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseButton : MonoBehaviour
{
    [SerializeField] private static bool pause = false;
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject deathPanel;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (PlayerPrefs.GetInt("death") > 0)
        {
            deathPanel.SetActive(true);
            Time.timeScale = 0f;
            pause = true;
        }
        else
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (pause)
            {
                Play();
            }
            else
            {
                Stop();
            }
        }
    }

    public void Play()
    {
        pausePanel.SetActive(false);
        deathPanel.SetActive(false);
        Time.timeScale = 1f;
        pause = false;
    }

    public void Stop()
    {
        pausePanel.SetActive(true);
        deathPanel.SetActive(false);
        Time.timeScale = 0f;
        pause = true;
    }

    public void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
