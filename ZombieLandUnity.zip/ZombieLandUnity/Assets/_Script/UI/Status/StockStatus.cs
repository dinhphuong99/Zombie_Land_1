using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class StockStatus : MonoBehaviour
{
    public StockBullet stockBullet;
    public StockHealthBox stockHealthBox;
    [SerializeField] private TextMeshProUGUI stockBulletText;
    [SerializeField] private TextMeshProUGUI stockHealthBoxText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        stockBulletText.text = stockBullet.bulletsInStock.ToString();
        stockHealthBoxText.text = stockHealthBox.stockHealthInStock.ToString();
    }
}
