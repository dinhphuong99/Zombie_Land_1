using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HPProcess : MonoBehaviour
{
    [SerializeField] private new GameObject gameObject;
    private TotalLife totalLife;
    private float currentValue;
    private float maxValue;
    private ProcessBar processBar;

    // Start is called before the first frame update
    void Start()
    {
        totalLife = gameObject.GetComponent<TotalLife>();
        processBar = GetComponent<ProcessBar>();
    }

    void Update()
    {
        if (totalLife != null)
        {
            maxValue = totalLife.maxHealth;
            currentValue = totalLife.currentHealth;
        }

        processBar.UpdateBar(currentValue, maxValue);
    }
}