using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundSelected : MonoBehaviour
{
    public int indexCharacter;
    public GameObject backgroundImage;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {
        if(indexCharacter == PlayerPrefs.GetInt("SelectedCharacterIndex") 
            && backgroundImage.active == false)
        {
            backgroundImage.SetActive(true);
        }else if (indexCharacter != PlayerPrefs.GetInt("SelectedCharacterIndex")
            || backgroundImage.active == true)
        {
            backgroundImage.SetActive(false);
        }
    }
}
