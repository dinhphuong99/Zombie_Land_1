﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterSelectionManager : MonoBehaviour
{
    [SerializeField] private List<GameObject> characters;

    void Start()
    {
        if (characters == null || characters.Count == 0)
        {
            return;
        }
        UpdateCharacter();
    }

    void UpdateCharacter()
    {
        foreach (GameObject obj in characters)
        {
            obj.SetActive(false);
        }

        characters[PlayerPrefs.GetInt("SelectedCharacterIndex")].SetActive(true);
    }

    public void SelectCharacter(int current)
    {
        PlayerPrefs.SetInt("SelectedCharacterIndex", current);
        PlayerPrefs.Save();
    }

    public void LoadSelectedCharacter()
    {
        if (PlayerPrefs.HasKey("SelectedCharacterIndex"))
        {
            if (characters == null || characters.Count == 0)
            {
                return;
            }

            UpdateCharacter();
        }
    }
}