using System.Collections;
using UnityEngine;
using TMPro;

public class NotificationText : MonoBehaviour
{
    public GameObject[] gunContainers;
    public StockHealthBox stockHealthBox;
    public StockBullet stockBullet;

    [SerializeField] private TextMeshProUGUI valueText;
    private Coroutine clearTextCoroutine;
    public float timeLife = 2.5f;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {
        string newText = "";

        if (Input.GetButton("Fire1") && CheckGun() && stockBullet.bulletsInStock <= 0)
        {
            newText = "Out of first ammo";
        }
        else if (Input.GetButton("Heal") && stockHealthBox.stockHealthInStock <= 0)
        {
            newText = "Out of first aid kit";
        }

        if (valueText.text != newText)
        {
            valueText.text = newText;

            if (clearTextCoroutine != null)
            {
                StopCoroutine(clearTextCoroutine);
            }

            if (!string.IsNullOrEmpty(newText))
            {
                clearTextCoroutine = StartCoroutine(ClearTextAfterDelay(timeLife));
            }
        }
    }

    [System.Obsolete]
    public bool CheckGun()
    {
        foreach (GameObject obj in gunContainers)
        {
            if (obj.active && obj.transform.childCount > 0)
            {
                return true;
            }
        }

        return false;
    }

    private IEnumerator ClearTextAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        valueText.text = "";
    }
}
