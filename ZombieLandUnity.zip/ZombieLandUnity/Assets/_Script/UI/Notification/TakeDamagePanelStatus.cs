﻿using System.Collections;
using UnityEngine;

public class TakeDamagePanelStatus : MonoBehaviour
{
    public TotalLife totalLife;
    private float previousCurentHealth;
    public GameObject plane;

    // Start is called before the first frame update
    void Start()
    {
        previousCurentHealth = totalLife.currentHealth;
        if (plane != null)
        {
            plane.SetActive(false); // Đảm bảo plane bắt đầu ở trạng thái deactive
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (previousCurentHealth < totalLife.currentHealth)
        {
            StartCoroutine(ActivateAndDeactivatePlane());
        }

        previousCurentHealth = totalLife.currentHealth; // Cập nhật previousCurentHealth để kiểm tra lần tiếp theo
    }

    private IEnumerator ActivateAndDeactivatePlane()
    {
        if (plane != null)
        {
            plane.SetActive(true);
            yield return new WaitForSeconds(0.3f);
            plane.SetActive(false);
        }
    }
}