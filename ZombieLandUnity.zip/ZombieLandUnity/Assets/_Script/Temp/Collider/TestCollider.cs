﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestCollider : MonoBehaviour
{
    [SerializeField] protected string tagTakeDamage;
    [SerializeField] protected float damage = 10f;
    protected Life life;
    [SerializeField] protected bool isSent = false;
    private List<GameObjectCanSent> ListObjectSentDamage = new List<GameObjectCanSent>();
    private List<GameObject> ListObjectExit = new List<GameObject>();

    class GameObjectCanSent
    {
        public GameObject obj;
        public bool isSent;
    }

    // Start is called before the first frame update
    void Start()
    {
        this.isSent = true;
        ListObjectSentDamage.Clear();

        Collider colliderComponent = GetComponent<Collider>();
        if (colliderComponent == null)
        {
            colliderComponent = gameObject.AddComponent<MeshCollider>();
            colliderComponent.isTrigger = true;
        }

        Rigidbody rigidbodyComponent = GetComponent<Rigidbody>();
        if (rigidbodyComponent == null)
        {
            rigidbodyComponent = gameObject.AddComponent<Rigidbody>();
            rigidbodyComponent.useGravity = false;
        }
    }


    public void SetFalse2IsSent()
    {
        this.isSent = false;
    }

    public void SetTrue2IsSent()
    {
        this.isSent = true;
        for (int i = 0; i < ListObjectSentDamage.Count; i++)
        {
            ListObjectSentDamage[i].isSent = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!this.isSent)
        {
            foreach (GameObjectCanSent gameObject in ListObjectSentDamage)
            {
                SendDamage(gameObject);
            }
        }
        else
        {
            foreach (GameObject gameObject in ListObjectExit)
            {
                try
                {
                    ListObjectSentDamage.RemoveAt(CheckObjectInList(gameObject));
                }
                catch (Exception e)
                {

                }
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {
            
            if (!(CheckObjectInList(collision.gameObject) > -1)
                && (collision.gameObject.GetComponent<Life>() != null))
            {
                GameObjectCanSent gameObjectCanSent = new GameObjectCanSent();
                gameObjectCanSent.obj = collision.gameObject;
                gameObjectCanSent.isSent = false;

                ListObjectSentDamage.Add(gameObjectCanSent);
            }
        }
    
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {
            if (!(CheckObjectInList(collision.gameObject) > -1)
                && (collision.gameObject.GetComponent<Life>() != null))
            {
                GameObjectCanSent gameObjectCanSent = new GameObjectCanSent();
                gameObjectCanSent.obj = collision.gameObject;
                gameObjectCanSent.isSent = false;

                ListObjectSentDamage.Add(gameObjectCanSent);
            }
        }
    
    }


    protected void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {
            ListObjectExit.Add(collision.gameObject);
        }
    }

    protected void OnTriggerExit(Collider collision)
    {
        if (collision.gameObject.CompareTag(tagTakeDamage))
        {
            ListObjectExit.Add(collision.gameObject);
        }
    }


    private void SendDamage(GameObjectCanSent gameObjectCanSent)
    {
        if (!gameObjectCanSent.isSent)
        {
            life = gameObjectCanSent.obj.GetComponent<Life>();

            if (life != null)
            {
                life.TakeDamage(damage);
                gameObjectCanSent.isSent = true;
            }
        }

    }

    private int CheckObjectInList(GameObject obj)
    {
        for (int i = 0; i < ListObjectSentDamage.Count; i++)
        {
            if (ListObjectSentDamage[i].obj.GetInstanceID() == obj.GetInstanceID())
            {
                return i;
            }
        }

        return -1;
    }

}
