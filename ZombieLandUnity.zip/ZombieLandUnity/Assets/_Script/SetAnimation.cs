using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetAnimation : MonoBehaviour
{
    protected Animator anim;
    protected string currentState = "";
    protected string defaultState = "";
    protected bool isCancelAnimation = false;

    // Start is called before the first frame update
    protected void Start()
    {
        anim = GetComponent<Animator>();

        // Get the default animation state from the Animation Controller
        AnimatorStateInfo state = anim.GetCurrentAnimatorStateInfo(0);

        // Set the currentState to the default animation state
        defaultState = state.fullPathHash.ToString();

        currentState = defaultState;
    }

    protected void ChangeAnimationState(string newState)
    {
        if (anim == null)
        {
            Debug.LogError("Animator is not assigned!");
            return;
        }

        if (string.IsNullOrEmpty(newState))
        {
            Debug.LogError("New state is null or empty!");
            return;
        }

        if (!anim.HasState(0, Animator.StringToHash(newState)))
        {
            Debug.LogError("New state is not a valid animator state: " + newState);
            return;
        }

        if (anim.GetCurrentAnimatorStateInfo(0).IsName(newState))
        {
            return;
        }

        currentState = newState;
        anim.Play(currentState);
    }

    
}

