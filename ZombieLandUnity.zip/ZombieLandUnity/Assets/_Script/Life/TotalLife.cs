using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TotalLife : MonoBehaviour
{
    private Life life;
    public GameObject[] objectLife;

    public float currentHealth;
    public float maxHealth;

    // Start is called before the first frame update
    void Start()
    {
        PlayerPrefs.SetInt("death", 0);
        PlayerPrefs.Save();
    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {
        UpdateHealth();
    }

    [System.Obsolete]
    public void UpdateHealth()
    {
        foreach (GameObject obj in objectLife)
        {
            if (obj.active)
            {
                life = obj.GetComponent<Life>();
                maxHealth = life.maxHealth;
                currentHealth = life.currentHealth;
                break;
            }
        }

        if(currentHealth <= 0f)
        {
            PlayerPrefs.SetInt("death", 1);
            PlayerPrefs.Save();
        }
        else
        {
            PlayerPrefs.SetInt("death", 0);
            PlayerPrefs.Save();
        }
    }
}
