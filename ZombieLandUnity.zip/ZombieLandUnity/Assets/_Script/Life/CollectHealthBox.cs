﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectHealthBox : MonoBehaviour
{
    private StockHealthBox stockHealthBox;
    public float healthBoxAdd;
    public float pickUpRange;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    [Obsolete]
    void Update()
    {
        //Check if player is in range

        GameObject player = FindObjWithTagAndActive("PlayerMain");

        if (player != null)
        {
            Vector3 distanceToPlayer = player.transform.position - transform.position;

            if (distanceToPlayer.magnitude <= pickUpRange
            && Input.GetButton("PickUp"))
            {
                stockHealthBox = player.GetComponent<StockHealthBox>();
                stockHealthBox.stockHealthInStock = stockHealthBox.stockHealthInStock + healthBoxAdd;
                DestroyObject(this.gameObject);
            }
        }

    }

    private GameObject FindObjWithTagAndActive(string tagObject)
    {
        /// Tìm tất cả các GameObject có tag "tagObject"
        GameObject[] objs = GameObject.FindGameObjectsWithTag(tagObject);

        // Lặp qua từng GameObject để kiểm tra điều kiện
        foreach (GameObject obj in objs)
        {
            // Kiểm tra xem GameObject có tồn tại và đang active không
            if (obj != null && obj.activeSelf)
            {
                return obj;
            }
        }

        return null;
    }
}
