using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StockHealthBox : MonoBehaviour
{
    public float stockHealthInStock = 0f;
    public List<GameObject> lifeObject = new List<GameObject>();

    private Life lifeChoose;
    public float healHP;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        foreach (GameObject obj in lifeObject)
        {
            if (obj.activeSelf)
            {
                lifeChoose = obj.GetComponent<Life>();
                break;
            }
        }

        if (Input.GetButton("Heal") && lifeChoose.currentHealth < lifeChoose.maxHealth && stockHealthInStock > 0)
        {
            lifeChoose.IncreaseHealth(healHP);
        }
    }
}
