using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Life : MonoBehaviour
{
    public float maxHealth = 100;
    //[HideInInspector] 
    public float currentHealth;

    // Start is called before the first frame update
    protected void Start()
    {
        currentHealth = maxHealth;
        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
        }
    }

    private void Update()
    {
        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
        }
    }

    public virtual void TakeDamage(float damage)
    {
        if (currentHealth > 0)
        {
            currentHealth = currentHealth - damage;
        }else
        {
            currentHealth = 0;
        }
    }

    public void IncreaseHealth(float health)
    {
        currentHealth = currentHealth + health;
        if (currentHealth >= maxHealth)
        {
            currentHealth = maxHealth;
        }
    }
}