﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimation : SetAnimation
{
    private PlayerMovement playerMovement;
    private GunSystem gunSystem;
    public Life life;

    public GameObject gunContainer;
    [HideInInspector] public bool isMove = false;
    [HideInInspector] public bool isDie = false;
    [HideInInspector] public bool isRun = false;
    [HideInInspector] public bool isCrouch = false;
    [HideInInspector] public bool isShoot = false;
    [HideInInspector] public bool isReload = false;
    [HideInInspector] public bool isJump = false;
    [HideInInspector] public bool isAttack = false;
    bool isAttackFinish = true;

    private new void Start()
    {
        base.Start();
        playerMovement = this.transform.parent.GetComponent<PlayerMovement>();
        CheckGunSystem();
    }

    private void CheckGunSystem()
    {
        if (gunContainer != null && gunContainer.transform.childCount > 0)
        {
            gunSystem = gunContainer.transform.GetChild(0).GetComponent<GunSystem>();
        }
    }

    void Update()
    {
        // Cập nhật lại gunSystem nếu gunContainer thay đổi
        if (gunContainer != null && gunContainer.transform.childCount > 0 && gunSystem == null)
        {
            CheckGunSystem();
        }

        if (life == null || life.currentHealth <= 0f)
        {
            isDie = true;
        }
        else
        {
            isDie = false;
        }

        isMove = playerMovement.GetIsMove();
        isRun = playerMovement.GetIsRun();
        isCrouch = playerMovement.GetIsCrouch();
        isJump = playerMovement.GetIsJump();
        isReload = (gunSystem != null) ? gunSystem.reloading : false;
        isShoot = (gunSystem != null) ? gunSystem.shootSound : false;
        isAttack = Input.GetButton("Fire1") && gunSystem == null;
        
        UpdateAnimationState();
    }

    public void AttackFinish()
    {
        isAttackFinish = true;
    }

    private void UpdateAnimationState()
    {
        if (isDie)
        {
            AttackFinish();
            ChangeAnimationState("Die");
        }
        else if (gunContainer.transform.childCount > 0)
        {
            if (isJump)
            {
                AttackFinish();
                ChangeAnimationState("Jump Forward");
            }
            else if (isRun)
            {
                AttackFinish();
                ChangeAnimationState("Rifle Run");
            }
            else if (isCrouch)
            {
                AttackFinish();
                ChangeAnimationState("Rifle Walk");
            }
            else if (isMove)
            {
                AttackFinish();
                ChangeAnimationState("Rifle Walk");
            }
            else if (isReload)
            {
                AttackFinish();
                ChangeAnimationState("Reloading");
            }
            else if (isShoot)
            {
                isAttackFinish = false;
                ChangeAnimationState("Firing Rifle");
            }
            else if (isAttackFinish)
            {
                ChangeAnimationState("Rifle Aim");
            }
        }
        else
        {
            
            if (isAttack)
            {
                isAttackFinish = false;
                ChangeAnimationState("Cross Punch");
            }
            else if (isJump)
            {
                AttackFinish();
                ChangeAnimationState("Jump");
            }
            else if (isRun)
            {
                AttackFinish();
                ChangeAnimationState("Run");
            }
            else if (isCrouch)
            {
                AttackFinish();
                ChangeAnimationState("Crouch Walk");
            }
            else if (isMove)
            {
                AttackFinish();
                ChangeAnimationState("Walk");
            }
            else if (isAttackFinish)
            {
                ChangeAnimationState("Idle");
            }
        }
    
    }
}

