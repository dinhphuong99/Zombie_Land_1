using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float playerSpeed = 1.9f;
    public float playerSprint = 3f;
    public float playerCrouch = 1f;

    private float speed = 0f;
    public float jumpForce = 0.5f;

    private CharacterController controller;
    // private float verticalVelocity;
    public Camera playerCamera; // Thêm biến để lưu trữ tham chiếu đến camera

    private float targetAngle = 0f;
    private float angle = 0f;
    private Vector3 direction;
    private Vector3 moveDirection;
    public float turnCalmTime = 1.9f;
    float turnClamVelocity;

    private float gravity = -9.81f;
    public float jumpRange = 1f;
    Vector3 velocity;

    private bool isMove = false;
    private bool isRun = false;
    private bool isCrouch = false;
    private bool isJump = false;


    public bool GetIsMove()
    {
        return this.isMove;
    }

    public bool GetIsRun()
    {
        return this.isRun;
    }

    public bool GetIsCrouch()
    {
        return this.isCrouch;
    }

    public bool GetIsJump()
    {
        return this.isJump;
    }

    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {

        ApplyGravity();
        Jump();
        
        MoveCharacter();
    }

    void MoveCharacter()
    {
        speed = playerSpeed;
        isRun = false;
        isMove = true;
        isCrouch = false;

        if (Input.GetButton("Sprint"))
        {
            speed = playerSprint;
            isRun = true;
            isMove = false;
            isCrouch = false;

        }
        else
        if (Input.GetButton("Crouch"))
        {
            speed = playerCrouch;
            isRun = false;
            isMove = false;
            isCrouch = true;
        }

        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        direction = new Vector3(horizontal, 0f, vertical).normalized;

        if (direction.magnitude >= 0.1f)
        {
            targetAngle = Mathf.Atan2(horizontal, vertical) * Mathf.Rad2Deg + playerCamera.transform.eulerAngles.y;
            angle = Mathf.SmoothDampAngle(transform.eulerAngles.y, targetAngle, ref turnClamVelocity, turnCalmTime);
            transform.rotation = Quaternion.Euler(0f, angle, 0f);
            moveDirection = Quaternion.Euler(0f, targetAngle, 0f) * Vector3.forward;

            controller.Move(moveDirection.normalized * speed * Time.unscaledDeltaTime);
        }
        else
        {
            isRun = false;
            isMove = false;
        }
    }

    void Jump()
    {
        
        // Xử lý nhảy
        if (controller.isGrounded)
        {
            isJump = false;
            if (Input.GetButtonDown("Jump"))
            {
                velocity.y = Mathf.Sqrt(jumpRange * -2 * gravity);
                isJump = true;
            }
        }
    }

    void ApplyGravity()
    {
        //onSurface = Physics.CheckSphere(surfaceCheck.position, surfaceDistance, surfaceMask);

        if (controller.isGrounded && velocity.y < 0f)
        {
            velocity.y = -0.01f;
        }
        else
        {
            velocity.y += gravity * Time.deltaTime;
            controller.Move(velocity * Time.deltaTime);
        }
    }

}