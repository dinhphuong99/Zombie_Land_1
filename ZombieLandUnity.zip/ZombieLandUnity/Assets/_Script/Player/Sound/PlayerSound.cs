﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSound : MonoBehaviour
{
    public PlayerAnimation playerAnimation;

    [Header("Locomotion Source")]
    public AudioSource jumpSource;
    public AudioSource walkSource;
    public AudioSource runSource;

    [Header("Death Source")]
    public AudioSource deathSource;

    [Header("Gun Source")]
    public AudioSource reloadSource;
    public AudioSource shootSource;

    private bool hasPlayedDeathSound = false;
    private bool hasPlayedJumpSound = false;
    private bool hasPlayedRunSound = false;
    private bool hasPlayedWalkSound = false;
    private bool hasPlayedReloadSound = false;
    private bool hasPlayedShootSound = false;

    void Start()
    {

    }

    void Update()
    {
        UpdateSound(playerAnimation.isDie, ref hasPlayedDeathSound, deathSource);
        UpdateSound(playerAnimation.isJump, ref hasPlayedJumpSound, jumpSource);

        // Dừng âm thanh bước đi và chạy khi nhảy
        if (playerAnimation.isJump)
        {
            StopSound(ref hasPlayedWalkSound, walkSource);
            StopSound(ref hasPlayedRunSound, runSource);
        }
        else
        {
            UpdateSound(playerAnimation.isRun, ref hasPlayedRunSound, runSource);
            UpdateSound(playerAnimation.isMove, ref hasPlayedWalkSound, walkSource);
        }

        if (playerAnimation.gunContainer != null && playerAnimation.gunContainer.transform.childCount > 0)
        {
            UpdateSound(playerAnimation.isReload, ref hasPlayedReloadSound, reloadSource);
            UpdateSound(playerAnimation.isShoot, ref hasPlayedShootSound, shootSource);
        }
        else
        {
            StopSound(ref hasPlayedReloadSound, reloadSource);
            StopSound(ref hasPlayedShootSound, shootSource);
        }
    }

    private void UpdateSound(bool condition, ref bool hasPlayed, AudioSource audioSource)
    {
        if (condition)
        {
            if (!hasPlayed)
            {
                audioSource.Play();
                hasPlayed = true;
            }
        }
        else
        {
            if (hasPlayed)
            {
                audioSource.Stop();
                hasPlayed = false;
            }
        }
    }

    private void StopSound(ref bool hasPlayed, AudioSource audioSource)
    {
        if (hasPlayed)
        {
            audioSource.Stop();
            hasPlayed = false;
        }
    }
}