﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioRangeManager : MonoBehaviour
{
    public float maxDistance = 20f;
    public float checkInterval = 0.5f; // Thời gian giữa các lần kiểm tra
    private AudioListener audioListener;
    private AudioSource[] audioSources;

    void Start()
    {
        audioListener = FindObjectOfType<AudioListener>();
        if (audioListener == null)
        {
            Debug.LogError("No AudioListener found in the scene.");
            return;
        }

        audioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource source in audioSources)
        {
            source.enabled = false;
        }

        StartCoroutine(CheckAudioSourcesPeriodically());
    }

    IEnumerator CheckAudioSourcesPeriodically()
    {
        while (true)
        {
            CheckAudioSources();
            yield return new WaitForSeconds(checkInterval);
        }
    }

    void CheckAudioSources()
    {
        Vector3 listenerPosition = audioListener.transform.position;

        foreach (AudioSource source in audioSources)
        {
            float distance = Vector3.Distance(listenerPosition, source.transform.position);

            if (distance > maxDistance)
            {
                source.enabled = false;  // Disable the AudioSource if beyond maxDistance
            }
            else
            {
                source.enabled = true;  // Enable the AudioSource if within maxDistance

                // Adjust the volume based on distance
                source.volume = 1 - (distance / maxDistance);
            }
        }
    }
}