﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPointBulletBehaviour : MonoBehaviour
{
    public GameObject mainCamera;
    private Vector3 vectorDirect;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // Tạo một Quaternion biểu diễn quay theo giá trị Euler (15, 0, 0)
        Quaternion rotation = Quaternion.Euler(15, 0, 0);

        // Vector chỉ hướng mặc định (thường là Vector3.forward)
        Vector3 originalForward = Vector3.forward;

        // Biến đổi vector chỉ hướng bằng quaternions đã quay
        Vector3 rotatedDirection = rotation * originalForward;

        // rotatedDirection giờ đây chứa vector chỉ hướng sau khi quay.

        vectorDirect = mainCamera.transform.position;
        transform.position = mainCamera.transform.position + (vectorDirect.normalized * 7f);
    }
}
