using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStatus : MonoBehaviour
{
    public Life [] life;
    private Life chooseLife;

    public PlayerAnimation playerAnimation;
    public StockBullet stockBullet;

    [HideInInspector] public float bulletsInStock;
    [HideInInspector] public float currentHealth;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        foreach (Life li in life)
        {
            
        }
        bulletsInStock = stockBullet.bulletsInStock;
        //currentHealth = life.currentHealth;
    }
}
