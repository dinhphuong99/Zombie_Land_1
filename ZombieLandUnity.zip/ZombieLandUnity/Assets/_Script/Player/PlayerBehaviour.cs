using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBehaviour : MonoBehaviour
{
    private float directX = 0f;
    private float directY = 0f;
    private float directZ = 0f;
    private float targetAngle = 0f;

    private Vector3 direction;

    [Header("Player Movement")]
    public float playerSpeed = 1.9f;

    [Header("Player Animator and Gravity")]
    public CharacterController characterController;

    [Header("Player Jumping and Velocity")]
    public float turnCalmTime = 1.9f;
    float turnClamVelocity;

    private void PlayerMovement()
    {
        directX = Input.GetAxisRaw("Horizontal");
        directZ = Input.GetAxisRaw("Vertical");

        direction = new Vector3(directX, 0f, directZ).normalized;

        if(direction.magnitude >= 0.1f)
        {
            targetAngle = Mathf.Atan2(directX, directZ) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0f, targetAngle, 0f);
            characterController.Move(direction.normalized * playerSpeed * Time.unscaledDeltaTime);
        }
    }

    private void Update()
    {
        PlayerMovement();
    }
}