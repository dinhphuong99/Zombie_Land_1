using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunContainerEquip : MonoBehaviour
{
    private EquipController equipController;

    public string [] listKeyName;

    // set local position
    public Vector3 [] listLocalPosition;
    public Vector3 [] listLocalRotation;

    private bool checkChild = false;

    // Start is called before the first frame update
    void Start()
    {
        CheckEquipController();
    }

    private void CheckEquipController()
    {
        if (this.gameObject.transform.childCount > 0)
        {
            checkChild = true;
            equipController = this.gameObject.transform.GetChild(0).GetComponent<EquipController>();
        }
        else
        {
            checkChild = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        CheckEquipController();
        
        if (checkChild)
        {
            SetPositionWithKeyName(equipController.keyName);
        }
        else
        {
            this.gameObject.transform.localPosition = Vector3.zero;
            this.gameObject.transform.localRotation = Quaternion.identity;
        }
    }

    private void SetPositionWithKeyName(string keyName)
    {
        for(int i = 0; i < listKeyName.Length; i++)
        {
            if (listKeyName[i].Equals(keyName))
            {
                this.gameObject.transform.localPosition = listLocalPosition[i];
                this.gameObject.transform.localRotation = Quaternion.Euler(listLocalRotation[i]);
                return;
            }
        }
    }
}
