using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StockBullet : MonoBehaviour
{
    public float bulletsInStock;

    // Start is called before the first frame update
    void Start()
    {
        bulletsInStock = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetBulletsInStock(float bullets)
    {
        this.bulletsInStock = bullets;
    }
}
