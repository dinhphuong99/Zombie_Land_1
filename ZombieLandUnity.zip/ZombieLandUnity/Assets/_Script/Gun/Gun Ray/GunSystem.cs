﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunSystem : MonoBehaviour
{
    // Gun stats
    public int damage;
    public float timeBetweenShooting, range, spread, reloadTime, timeBetweenShoots;
    public int magazineSize, bulletsPerTap;
    public bool allowButtonHold;
    public bool equipped;
    public EquipController equipController;
    public GunRecoil gunRecoil;

    public GameObject ammoBag;
    private StockBullet stockBullet;

    public float bulletsLeft, bulletsShoot;

    // bools
    bool shooting = false;
    [HideInInspector] public bool reloading = false;
    [HideInInspector] public bool readyToShoot = false;
    [HideInInspector] public bool shootSound = false;

    // Reference
    public Camera fpsCam;
    public Transform attackPoint;
    public RaycastHit raycastHit;
    public LayerMask enemyMask; // Layer của enemy
    public LayerMask wallMask; // Layer của wall

    public GameObject goreEffectPrefab; // Prefab cho gore effect
    public GameObject woodEffectPrefab; // Prefab cho wood effect

    [SerializeField] protected ParticleSystem muzzleSpark;

    // Graphics
    //public CameraShaker camShake;
    public CameraShake camShake;
    public float camShakeDuration, camShakeMagnitude;

    Vector3 directWithSpead;
    public float GetBulletsLeft()
    {
        return this.bulletsLeft;
    }

    private void Awake()
    {
        bulletsLeft = 0f;//magazineSize;
        readyToShoot = true;
        stockBullet = ammoBag.GetComponent<StockBullet>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        equipped = equipController.equipped;
        
        if (equipped)
        {
            Shooting();
        }
    }

    private void Shooting()
    {
        if (allowButtonHold)
        {
            shooting = Input.GetButton("Fire1");
        }
        else
        {
            shooting = Input.GetButtonDown("Fire1");
        }

        //Reloading
        if (Input.GetButtonDown("Reload") && bulletsLeft < magazineSize && !reloading)
        {
            Reload();
        }

        //Reload automatically when trying to shoot without amo
        if (readyToShoot && shooting && !reloading && bulletsLeft <= 0 && stockBullet.bulletsInStock > 0f)
        {
            Reload();
        }
        
        //Shoot
        if (readyToShoot && shooting && !reloading && bulletsLeft > 0)
        {
            if (bulletsLeft > bulletsPerTap)
                bulletsShoot = bulletsPerTap;
            else
                bulletsShoot = bulletsLeft;

            Shoot();
        }
    }

    private void Shoot()
    {
        readyToShoot = false;
        shootSound = true;

        // Calculate spread
        float x = Random.Range(-spread, spread);
        float y = Random.Range(-spread, spread);

        // Calculate new direction with spread
        directWithSpead = fpsCam.transform.forward + new Vector3(x, y, 0f);

        muzzleSpark.Play();

        // Raycast
        CheckRaycast(wallMask, woodEffectPrefab);
        CheckRaycast(enemyMask, goreEffectPrefab);
        
        // camShake
        StartCoroutine(camShake.Shake(camShakeDuration, camShakeMagnitude));

        bulletsLeft--;
        bulletsShoot--;

        gunRecoil.Recoil();

        Invoke(nameof(ResetShoot), timeBetweenShooting);

        //if(bulletsShoot > 0 && bulletsLeft > 0)
        //{
        //    Invoke(nameof(Shoot), timeBetweenShoots);
        //}

        if (bulletsShoot > 0 && bulletsLeft > 0)
        {
            Invoke(nameof(Shoot), timeBetweenShoots);
        }
    }

    private void CheckRaycast(LayerMask collisionMask, GameObject effectPrefab)
    {
        if (Physics.Raycast(fpsCam.transform.position, directWithSpead, out raycastHit, range, collisionMask))
        {
            SpawnEffect(effectPrefab, raycastHit.point, raycastHit.normal);
            if (raycastHit.collider.GetComponent<Life>())
            {
                raycastHit.collider.GetComponent<Life>().TakeDamage(damage);
            }
        }
    }

    private void SpawnEffect(GameObject effectPrefab, Vector3 position, Vector3 normal)
    {
        // Kiểm tra xem có Prefab của hiệu ứng không
        if (effectPrefab != null)
        {
            // Tạo hiệu ứng tại vị trí va chạm với hướng normal
            GameObject effect = Instantiate(effectPrefab, position, Quaternion.LookRotation(normal));
            // Hủy hiệu ứng sau một khoảng thời gian
            Destroy(effect, 2.5f);
        }
    }

    private void ResetShoot()
    {
        readyToShoot = true;
        shootSound = false;
    }

    public void Reload()
    {
        if(stockBullet.bulletsInStock > 0)
        {
            reloading = true;
            Invoke(nameof(ReloadFinish), reloadTime);
        }
        
    }

    private void ReloadFinish()
    {
        if (stockBullet.bulletsInStock >= (magazineSize - bulletsLeft))
        {
            stockBullet.SetBulletsInStock(stockBullet.bulletsInStock - magazineSize
                + bulletsLeft);
            bulletsLeft = magazineSize;
        }
        else
        {
            bulletsLeft = bulletsLeft + stockBullet.bulletsInStock;
            stockBullet.SetBulletsInStock(0f);
        }
        
        reloading = false;
    }
}
