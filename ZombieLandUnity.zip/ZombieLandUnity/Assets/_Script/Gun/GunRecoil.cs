﻿using UnityEngine;

public class GunRecoil : MonoBehaviour
{
    public Transform gunTransform; // Tham chiếu đến Transform của súng
    public Transform spawnPoint;
    public float recoilAmount = 0.05f; // Độ giật của súng
    public float recoilSpeed = 5f; // Tốc độ giật của súng

    private Vector3 originalPosition; // Vị trí ban đầu của súng
    private bool isRecoiling = false; // Kiểm tra xem súng có đang giật hay không

    void Start()
    {
        originalPosition = gunTransform.localPosition;
    }

    void Update()
    {
        if (isRecoiling)
        {
            // Lerp để giảm dần hiệu ứng giật của súng
            gunTransform.localPosition = Vector3.Lerp(gunTransform.localPosition, originalPosition, recoilSpeed * Time.deltaTime);

            // Kết thúc hiệu ứng giật khi súng đã trở lại vị trí ban đầu
            if (Vector3.Distance(gunTransform.localPosition, originalPosition) == 0f)
            {
                isRecoiling = false;
            }
        }
    }

    public void Recoil()
    {
        // Áp dụng hiệu ứng giật bằng cách thay đổi vị trí của súng
        Vector3 recoilDirection = -(gunTransform.localPosition - spawnPoint.localPosition).normalized;//-gunTransform.forward;
        Vector3 recoilPosition = originalPosition - recoilDirection * recoilAmount;

        gunTransform.localPosition = recoilPosition;
        isRecoiling = true;
    }
}
