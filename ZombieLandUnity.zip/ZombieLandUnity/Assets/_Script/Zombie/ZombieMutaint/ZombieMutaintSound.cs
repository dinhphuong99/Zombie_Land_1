﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieMutaintSound : ZombieSound
{
    public AudioSource roarSource;
    protected bool hasPlayedRoarSound = false;
    public ZombieMutaintBehaviour zombieMutaintBehaviour;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    protected override void Update()
    {
        base.Update(); // Gọi hàm Update của lớp cha để giữ nguyên hành vi cũ

        // Thêm chức năng mới cho lớp con
        UpdateSound(zombieMutaintBehaviour.isRoar, ref hasPlayedRoarSound, roarSource, 3f);
    }

    protected override void StopOtherSounds(AudioSource currentAudioSource)
    {
        base.StopOtherSounds(currentAudioSource); // Gọi hàm cha để giữ nguyên hành vi cũ

        if (currentAudioSource != roarSource && roarSource.enabled)
        {
            roarSource.Stop();
            hasPlayedRoarSound = false;
        }
    }
}
