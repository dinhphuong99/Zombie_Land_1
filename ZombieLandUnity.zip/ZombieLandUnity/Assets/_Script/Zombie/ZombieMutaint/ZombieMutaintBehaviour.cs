﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieMutaintBehaviour : ZombieBehaviour
{
    [SerializeField] private float bonusChaseSpeed = 2f;
    [SerializeField] private float bonusAttackSpeed = 4f;
    [SerializeField] private float minDistanceJump = 1.5f;
    [SerializeField] private float maxDistanceJump = 2f;
    [HideInInspector] public bool isJumpAttack = false;
    [HideInInspector] public bool isRoar = false;
    [SerializeField] GameObject effectBuff;
    [SerializeField ] float timeBuff = 10f;
    protected bool isJumpTouch = false;
    float targetCheck = 100f;

    private int roarCount = 0; // Bộ đếm để theo dõi số lần kích hoạt
    private bool hasRoared75 = false; // Cờ cho mức 75%
    private bool hasRoared50 = false; // Cờ cho mức 50%
    private bool hasRoared25 = false; // Cờ cho mức 25%

    private void Update()
    {
        currentHealth = life.currentHealth;
        zombieAgent.SetDestination(targetObject.transform.position);
        targetCheck = targetBehaviour.targetCheck;

        if (life.currentHealth <= 0f)
        {
            isDeath = true;
            Invoke(nameof(Die), 1.5f);
        }
        else
        {
            CheckRoar();
            isDeath = false;
            isNull = targetBehaviour.isNull;
            isTouch = detectionCollider.isTouch;

            if (!zombieType.isCancelAnimation)
            {
                if (!isNull && isTouch && targetCheck < minTargetDistance)
                {
                    isAttack = true;
                    isJumpAttack = false;
                }
                else
                if (!isNull && targetCheck < maxDistanceJump
                    && targetCheck > minDistanceJump)
                {
                    isJumpAttack = true;
                    isAttack = false;
                }

                isRoar = false;
            }

            if (isJumpAttack)
            {
                zombieAgent.speed = baseSpeed + bonusAttackSpeed;
            }
            else if (isAttack || isRoar)
            {
                zombieAgent.speed = 0f;
            }
            else if (targetBehaviour.isChase)
            {
                zombieAgent.speed = baseSpeed + bonusChaseSpeed;
            }
            else
            {
                zombieAgent.speed = baseSpeed;
            }


        }
    }

    private void CheckRoar()
    {
        if (life.currentHealth <= life.maxHealth * 0.75f && !hasRoared75)
        {
            isRoar = true;
            hasRoared75 = true;
            roarCount++;
            StartCoroutine(ActivateEffectBuff());
        }
        else if (life.currentHealth <= life.maxHealth * 0.5f && !hasRoared50)
        {
            isRoar = true;
            hasRoared50 = true;
            roarCount++;
            StartCoroutine(ActivateEffectBuff());
        }
        else if (life.currentHealth <= life.maxHealth * 0.25f && !hasRoared25)
        {
            isRoar = true;
            hasRoared25 = true;
            roarCount++;
            StartCoroutine(ActivateEffectBuff());
        }

        // Đặt lại isRoar nếu roarCount đạt 3 lần
        if (roarCount >= 3)
        {
            isRoar = false;
        }
    }

    private IEnumerator ActivateEffectBuff()
    {
        effectBuff.SetActive(true);
        effectBuff.GetComponent<MutaintRoar>().Roar();
        yield return new WaitForSeconds(timeBuff);
        effectBuff.SetActive(false);
    }
}
