﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.AI;

public class HeallingSkill : MonoBehaviour
{
    [SerializeField] LayerMask targetLayer;
    [SerializeField] float healRadius = 4f;
    [SerializeField] float healRepeat = 6f;
    [SerializeField] float health = 10f;
    [SerializeField] Transform movingObject;
    List<GameObject> listObjects = new List<GameObject>();
    [SerializeField] ParticleSystem heallingEffect;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating(nameof(Healling),0f, healRepeat);
    }

    // Update is called once per frame
    void Update()
    {
        heallingEffect.Stop();
    }

    private void Healling()
    {
        heallingEffect.Stop();
        listObjects.Clear();

        Collider[] colliders = Physics.OverlapSphere(movingObject.position, healRadius, targetLayer);

        foreach (Collider collider in colliders)
        {
            var obj = collider.gameObject;
            var life = obj.GetComponent<Life>();

            if (life != null)
            {
                life.IncreaseHealth(health);
            }
        }

        heallingEffect.Play();

    }
}
