﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.AI;

public class AverageSkillSpeed : MonoBehaviour
{
    private float baseSpeed;
    [SerializeField] LayerMask targetLayer;
    [SerializeField] string zombieTypeX;
    [SerializeField] float addSpeedRadius = 4f;
    [SerializeField] float averageSpeedRepeat = 0.6f;
    [SerializeField] Transform movingObject;
    [HideInInspector] public float speedTotal = 0f;


    public NavMeshAgent zombieAgent;

    List<GameObject> listObjects = new List<GameObject>();

    // Start is called before the first frame update
    void Start()
    {
        baseSpeed = zombieAgent.speed;
        InvokeRepeating(nameof(AverageSpeed), 0f, averageSpeedRepeat);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void AverageSpeed()
    {
        listObjects.Clear();

        Collider[] colliders = Physics.OverlapSphere(movingObject.position, addSpeedRadius, targetLayer);

        foreach (Collider collider in colliders)
        {
            listObjects.Add(collider.gameObject);
        }

        float count = 0f;
        speedTotal = 0f;
        foreach (GameObject obj in listObjects)
        {
            var zombieType = obj.GetComponent<ZombieType>();
            if (zombieType != null)
            {
                if (!zombieType.zombieType.Equals(zombieTypeX))
                {
                    speedTotal = speedTotal + zombieType.zombieAgent.speed;
                    count++;
                }
            }
        }

        if (count < 1f)
        {
            zombieAgent.speed = baseSpeed;
                return;
        }
        
        zombieAgent.speed = speedTotal / count;
    }
}
