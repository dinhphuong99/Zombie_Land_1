﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieSpeedAnimation : ZombieAnimation
{
    protected bool isJumpAttack = false;
    public ZombieSpeedBehaviour zombieSpeedBehaviour;

    // Start is called before the first frame update
    protected new void Start()
    {
        base.Start();
    }

    // Update is called once per frame
    protected void Update()
    {
        isDeath = zombieType.isDeath;
        isAttack = zombieType.isAttack;
        isJumpAttack = zombieSpeedBehaviour.isJumpAttack;
        isChase = zombieType.isChase;
        isWaiting = zombieType.isWaiting;
        UpdateAnimationState();
    }

    protected void UpdateAnimationState()
    {
        // Nếu animation "Attack" đang chạy và không phải là animation "Die",
        // không làm gì cả
        if (isCancelAnimation && !isDeath)
        {
            return;
        }
        else if (isDeath)
        {
            ChangeAnimationState("Die");
        }
        else if (isJumpAttack)
        {
            ChangeAnimationState("Jump Attack");
        }
        else if (isAttack)
        {
            ChangeAnimationState("Attack");
        }
        else if (isChase)
        {
            ChangeAnimationState("Chase");
        }
        else if (isWaiting)
        {
            ChangeAnimationState("Idle");
        }
        else
        {
            ChangeAnimationState("Move");
        }
    }

}
