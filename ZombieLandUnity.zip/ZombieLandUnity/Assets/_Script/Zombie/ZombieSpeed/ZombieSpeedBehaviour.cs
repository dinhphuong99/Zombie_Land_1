using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieSpeedBehaviour : ZombieBehaviour
{
    [SerializeField] private float bonusChaseSpeed = 5f;
    [SerializeField] private float bonusAttackSpeed = 9f;
    [SerializeField] private float minDistanceJump = 2.25f;
    [SerializeField] private float maxDistanceJump = 3f;
    [HideInInspector] public bool isJumpAttack = false;
    float constSpeedBack = 5f;
    protected bool isJumpTouch = false;
    float targetCheck = 100f;

    private void Update()
    {
        currentHealth = life.currentHealth;
        zombieAgent.SetDestination(targetObject.transform.position);
        targetCheck = targetBehaviour.targetCheck;

        if (life.currentHealth <= 0f)
        {
            isDeath = true;
            Invoke(nameof(Die), 1.5f);
        }
        else
        {
            isDeath = false;
            isNull = targetBehaviour.isNull;
            isTouch = detectionCollider.isTouch;

            isAttack = false;
            isJumpAttack = false;

            if (!isNull && targetCheck < maxDistanceJump
                && targetCheck > minDistanceJump)
            {
                isJumpAttack = true;
                isAttack = false;
            }

            if (!isNull && isTouch && targetCheck < minTargetDistance)
            {
                isAttack = true;
                isJumpAttack = false;
            }

            if (isJumpAttack)
            {
                zombieAgent.speed = baseSpeed + bonusAttackSpeed;
            }else if (isAttack)
            {
                zombieAgent.speed = 0f;
            }
            else if (targetBehaviour.isChase)
            {
                zombieAgent.speed = baseSpeed + bonusChaseSpeed;
            }
            else
            {
                zombieAgent.speed = baseSpeed;
            }
        }
    
    }
}
