using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingWithWaitTime : MonoBehaviour
{
    public GameObject[] walkPoints;
    public GameObject moveObject;
    int currentZombiePosition = 0;
    [HideInInspector] public float walkingpointRadius = 2f;

    public float waitingTime = 3.5f;
    [SerializeField] private float speed = 1.5f;
    [HideInInspector] public bool isWaiting = false;
    [HideInInspector] public float waitingTimer = 0f;

    // Update is called once per frame
    void Update()
    {
        
    }

    public void FollowWaypoint()
    {
        if (!isWaiting && Vector3.Distance(
            walkPoints[currentZombiePosition].transform.position,
            moveObject.transform.position) < walkingpointRadius)
        {
            currentZombiePosition++;
            if (currentZombiePosition >= walkPoints.Length)
            {
                currentZombiePosition = 0;
            }

            isWaiting = true;
        }

        if (isWaiting)
        {
            waitingTimer += Time.deltaTime;
            if (waitingTimer >= waitingTime)
            {
                isWaiting = false;
                waitingTimer = 0f;
            }
        }

        if (!isWaiting)
        {
            transform.position = Vector3.MoveTowards(transform.position,
            walkPoints[currentZombiePosition].transform.position, Time.deltaTime * speed);
        }
    }
}